var tools = {
    config: {
        container: null,
        retina: true
    },
    scaleWindow: function(scaleMod, x, y) {
        var a = this.config.container,
            b = window.innerHeight - 9,
            c = 756,
            d,
            e = $('#debugIMG'),
            f = $('body')[0];
        if (this.config.retina) c = 1536;
        a.css({
            'transform-origin': '0 0'
        });
        e.css({
            'transform-origin': '0 0'
        });

        function run() {
            if (b < c) {
                d = b / c;
                b = window.innerHeight - 9;
                a.css({
                    'transform': 'matrix(' + (d * scaleMod) + ', 0, 0, ' + (d * scaleMod) + ', 0, 0)'
                });
                e.css({
                    'transform': 'matrix(' + d * scaleMod + ', 0, 0, ' + (d * scaleMod) + ', 0, 0)'
                });
            } else {
                a.css({
                    'transform': 'matrix(1, 0, 0, 1, 0, 0)'
                });
                e.css({
                    'transform': 'matrix(1, 0, 0, 1, 0, 0)'
                });
            }
        }
        $(window).resize(run);
        run();
        setTimeout(function() {
            f.scrollLeft = x;
            f.scrollTop = y;
        }, 0);
    },
    showImg: function() {
        var that = this;
        $('body').prepend('<img id="debugIMG" width="'+that.config.container.width()+'" height="'+that.config.container.height()+'" src="debug.png" alt="" />');
        setTimeout(function(){
            that.config.container.css({
                'opacity': '.5'
            });
        },1000);
    },
    browser: function(scaleMod, x, y) {
        this.scaleWindow(scaleMod, x, y);
        $('body').css({
            'background-color': '#333',
            'position': 'absolute',
            'width': '100%',
            'height': '100%',
            'overflow': 'hidden'
        });
    },
    ipad: function(a, b, c, d) {
        $('body').css({
            'position': 'fixed',
            'width': '100%',
            'height': '100%'
        });
        $('body').append('<div id="IOSconsole" style="font-size: 15px;"><span></span><div style="position:absolute;top:-5px;left:-5px;padding:20px 25px;border:5px solid #000;background-color:#fff; width: auto;height:auto;">X</div></div>');
        styleObj = {
            'position': 'absolute',
            'top': 'auto',
            'left': 'auto',
            'right': 'auto',
            'bottom': 'auto',
            'width': '0',
            'height': '0',
            'opacity': '0',
            'border': '5px solid #000',
            'overflow': 'scroll',
            'transition': 'all 300ms cubic-bezier(0,.5,.5,1.5)',
            '-webkit-transition': 'all 300ms cubic-bezier(0,.5,.5,1.5)',
            'background-color': '#fff',
            '-webkit-overflow-scrolling': 'touch',
            'box-sizing': 'border-box',
            'padding': '0',
            'border-radius': '5px'
        };
        var styleObj2 = {};
        styleObj[a] = 0;
        styleObj[b] = 0;
        styleObj2.width = c + '%';
        styleObj2.height = d + '%';
        styleObj2.padding = '50px 20px 0px 50px';
        styleObj2.opacity = '1';
        var styleObj3 = {};
        styleObj3.width = '';
        styleObj3.height = '';
        styleObj3.padding = '';
        var MODconsole = $('#IOSconsole');
        var CloseButton = MODconsole.find('> div');
        MODconsole.css(styleObj);
        var span = MODconsole.find('> span');

        function log(text) {}
        MODconsole.scroll(function() {
            CloseButton.css({
                'transform': 'matrix(1,0,0,1,' + (MODconsole.scrollLeft()) + ',' + (MODconsole.scrollTop()) + ')'
            });
        });
        var now = new Date();
        var h = now.getHours();
        if (h > 12) h = h - 12;
        var s = now.getSeconds();
        var m = now.getMinutes();
        var mil = now.getMilliseconds();
        var time = h + ':' + m + ':' + mil;
        window.console.log = function(text) {
            var txt = text;
            if (typeof txt == 'object') txt = JSON.stringify(txt);
            now = new Date();
            h = now.getHours();
            if (h > 12) h = h - 12;
            m = now.getMinutes();
            s = now.getSeconds();
            mil = now.getMilliseconds();
            time = h + ':' + m + ':' + s + ':' + mil;
            if (MODconsole.width() < 1) {
                MODconsole.css(styleObj2);
            }
            span.append('/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/<br/><span style="position:relative; margin-left: -15px; left: -30px; font-size:.5em;">' + time + '</span>' + txt + '<br/>/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/\\/<br/>');
            MODconsole.scrollTop(span.height());
        };
        CloseButton.on('tap', function(e) {
            MODconsole.css(styleObj);
        });
    },
	runInSuccesion: function(a,d,e){function c(f){b++;setTimeout(function(){b<=a.length?(f(),c(a[b])):d()},e)}var b=0;c(a[0])},
	SuccesiveUI: function(b,e,f){function d(a){c++;setTimeout(function(){c<=b.length?(console.log(a[0],a[0].length),$(a[0]).trigger(a[1]),d(b[c])):e()},f)}var c=0;d(b[0])}

};

// configer this object to work with you project here
tools.config.retina = false;
tools.config.container = $('#container');




// call the public functions of this object here

// tools.showImg(); // makes the container transparent, and shows an image of the PSD behind everything



// if(window.location.href.indexOf('scale=true') > -1){ // if you pass scale=true' as a get request, the content will scale to match the height of the window
	// tools.browser(1 , 0, 0); // scales page to fit inside a browser by height - zoom level, scrollLeft, scrollTop
// }



tools.ipad('bottom', 'right', 50, 45); // console emulator for ipad - position, position, %width, %height


var specificIssueDebug = {
	preventDouble: 0,
	init:function(el){
		var that = this;
		$('body').on('tap', function(e){
			if(that.preventDouble) return false;
			that.preventDouble = 1;
			setTimeout(function(){
				that.preventDouble = 0;
			},25);
			console.log('data-referer:   -  ' + el.attr('data-referer'));
			console.log('data-browseanpage   -  ' + el.attr('data-browseanpage'));
		});
	}
};

specificIssueDebug.init($('#container'));
