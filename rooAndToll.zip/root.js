var app = {
    pageScripts: {

    },
    nav: {
        var: {
            view: {},
            MainButtons: {

            },
            RunFlag : 0,
            lastURL: '',
            currentURL: 'views/home/index.html'
        },
        activeStates: function(localThis) {
            var that = this;
            var currentClass;
            var newClass = localThis.attr('data');
            currentClass = that.var.nav.attr('data');
            that.var.nav.attr('data', newClass);
            that.var.nav.find('.active').removeClass('active');
            if (currentClass != newClass) {
                that.var.nav.removeClass(currentClass);
                that.var.nav.addClass(newClass);
            }
            setTimeout(function() {
                localThis.addClass('active');
            }, 0);
        },
        imgpreload: function(b, f) {
            var d = 0,
                c = [];
            b = "[object Array]" === Object.prototype.toString.apply(b) ? b : [b];
            for (var e = function() {
                    d += 1;
                    d === b.length && f && f(c)
                }, a = 0; a < b.length; a++) c[a] = new Image, c[a].onabort = e, c[a].onerror = e, c[a].onload = e, c[a].src = b[a]
        },
        checkImages: function(element, callback) {
            var that = this;
            var arr = [];
            var LocalThis;

            function uniq(a) {
                var prims = {
                        "boolean": {},
                        "number": {},
                        "string": {}
                    },
                    objs = [];
                return a.filter(function(item) {
                    var type = typeof item;
                    if (type in prims)
                        return prims[type].hasOwnProperty(item) ? false : (prims[type][item] = true);
                    else
                        return objs.indexOf(item) >= 0 ? false : objs.push(item);
                });
            }
            setTimeout(function() {
                $.each(element.find('img'), function() {
                    LocalThis = $(this);
                    arr.push($(this).attr('src'));

                });
                $.each(element.find('*'), function() {

                    LocalThis = $(this);
                    a = $(this).css('background-image');

                    if (a[0] == 'u') {
                        arr.push(a.replace(/\'/g, '').replace(/\"/g, '').replace('url(', '').replace(')', ''));
                    }
                });
                arr = uniq(arr);
                if (arr.length) {
                    that.imgpreload(arr, function() {
                        callback();
                    });
                } else {
                    callback();
                }
            }, 10);

        },
        return: function() {
            var that = this;
            var last = $('.view.active');
            var target = last.index();
            target = target + 1;
            if (target > 1) target = 0;
            target = $($('.view')[target]);

            target.addClass('target');
            last.addClass('last');

            target[0].style.zIndex = '3';
            target[0].style.transform = 'matrix(1,0,0,1,-924,0)';
            target[0].style.webkitTransform = 'matrix(1,0,0,1,-924,0)';
            setTimeout(function() {
                target[0].style.width = '100%';
                target[0].style.height = '100%';
                setTimeout(function() {
                    target[0].style.transition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                    target[0].style.webkitTransition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                    target[0].style.transform = 'matrix(1,0,0,1,0,0)';
                    target[0].style.webkitTransform = 'matrix(1,0,0,1,0,0)';
                    last[0].style.transition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                    last[0].style.webkitTransition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                    last[0].style.transform = 'matrix(1,0,0,1,924,0)';
                    last[0].style.webkitTransform = 'matrix(1,0,0,1,924,0)';
                    setTimeout(function() {
                        // ClearStyles();
                        // if (that.var.view.active) {
                        //     that.var.view.active = 0;
                        // } else {
                        //     that.var.view.active = 1;
                        // }
                        last.removeClass('active');
                        last[0].style.zIndex = '';
                        last[0].style.width = '';
                        last[0].style.height = '';
                        last[0].style.transition = '';
                        last[0].style.webkitTransition = '';
                        last[0].style.transform = '';
                        last[0].style.webkitTransform = '';
                        last[0].style.opacity = '';
                        target.addClass('active');
                        target[0].style.zIndex = '';
                        target[0].style.width = '';
                        target[0].style.height = '';
                        target[0].style.transition = '';
                        target[0].style.webkitTransition = '';
                        target[0].style.transform = '';
                        target[0].style.webkitTransform = '';
                        target[0].style.opacity = '';
                        that.var.runFlag = 0;
                        setTimeout(function() {
                            if (!that.var.preventUnload) last.html('');
                            app.pageScripts[that.var.persistant] = null;
                        }, 50);
                    }, 775);
                }, 50);
            }, 10);
        },
        load: function(url, direction, button, preventUnload) {
            // console.log('navigating to:' + url);
            app.popups.var.navigating = 1;
            setTimeout(function(){
                app.popups.var.navigating = 0;
            },200);
            if (this.var.runFlag) return false;
            this.var.runFlag = 1;
            if (preventUnload) this.var.persistant = url;
            var that = this;
            var target;
            var last;
            if (this.var.view.active) {
                target = this.var.view[0];
                last = this.var.view[1];
            } else {
                target = this.var.view[1];
                last = this.var.view[0];
            }
            that.var.lastURL = that.var.currentURL;
            that.var.currentURL = url;



            function ClearStyles() {
                $('.BlockScrolling').removeClass('BlockScrolling');
                if(!preventUnload)app.pageScripts[url] = null;
                last.removeClass('active');
                last[0].style.zIndex = '';
                last[0].style.width = '';
                last[0].style.height = '';
                last[0].style.transition = '';
                last[0].style.webkitTransition = '';
                last[0].style.transform = '';
                last[0].style.webkitTransform = '';
                last[0].style.opacity = '';
                target.addClass('active');
                target[0].style.zIndex = '';
                target[0].style.width = '';
                target[0].style.height = '';
                target[0].style.transition = '';
                target[0].style.webkitTransition = '';
                target[0].style.transform = '';
                target[0].style.webkitTransform = '';
                target[0].style.opacity = '';
                target[0].style.backfaceVisibility = '';
                target[0].style.webkitBackfaceVisibility = '';
                target[0].style.perspective = '';
                target[0].style.webkitPerspective = '';
                last[0].style.backfaceVisibility = '';
                last[0].style.webkitBackfaceVisibility = '';
                last[0].style.perspective = '';
                last[0].style.webkitPerspective = '';
                setTimeout(function() {
                    if (!preventUnload) last.html('');
                    that.var.runFlag = 0;
                }, 250);
            }
            target.attr('data', url);
            target.load(url, function() {
                that.checkImages(target, function() {
                    setTimeout(function() {
                        target[0].style.backfaceVisibility = 'hidden';
                        target[0].style.webkitBackfaceVisibility = 'hidden';
                        target[0].style.perspective = '1000';
                        target[0].style.webkitPerspective = '1000';
                        last[0].style.backfaceVisibility = 'hidden';
                        last[0].style.webkitBackfaceVisibility = 'hidden';
                        last[0].style.perspective = '1000';
                        last[0].style.webkitPerspective = '1000';
                        switch (direction) {
                            case 'center':
                                target[0].style.zIndex = '3';
                                target[0].style.width = '100%';
                                target[0].style.height = '100%';
                                target[0].style.opacity = '0';
                                setTimeout(function() {
                                    target[0].style.transition = 'opacity 20ms linear';
                                    target[0].style.webkitTransition = 'opacity 20ms linear';
                                    target[0].style.opacity = '1';
                                    setTimeout(function() {
                                        ClearStyles();
                                        if (that.var.view.active) {
                                            that.var.view.active = 0;
                                        } else {
                                            that.var.view.active = 1;
                                        }
                                    }, 25);
                                }, 10);
                                break;
                            case 'left':
                                target[0].style.zIndex = '3';
                                target[0].style.transform = 'matrix(1,0,0,1,-924,0)';
                                target[0].style.webkitTransform = 'matrix(1,0,0,1,-924,0)';
                                setTimeout(function() {
                                    target[0].style.width = '100%';
                                    target[0].style.height = '100%';
                                    setTimeout(function() {
                                        target[0].style.transition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                                        target[0].style.webkitTransition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                                        target[0].style.transform = 'matrix(1,0,0,1,0,0)';
                                        target[0].style.webkitTransform = 'matrix(1,0,0,1,0,0)';
                                        last[0].style.transition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                                        last[0].style.webkitTransition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                                        last[0].style.transform = 'matrix(1,0,0,1,924,0)';
                                        last[0].style.webkitTransform = 'matrix(1,0,0,1,924,0)';
                                        setTimeout(function() {
                                            ClearStyles();
                                            if (that.var.view.active) {
                                                that.var.view.active = 0;
                                            } else {
                                                that.var.view.active = 1;
                                            }
                                        }, 775);
                                    }, 50);
                                }, 25);

                                break;
                            case 'right':
                                target[0].style.zIndex = '3';
                                target[0].style.transform = 'matrix(1,0,0,1,924,0)';
                                target[0].style.webkitTransform = 'matrix(1,0,0,1,924,0)';
                                setTimeout(function() {
                                    target[0].style.width = '100%';
                                    target[0].style.height = '100%';
                                    setTimeout(function() {
                                        target[0].style.transition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                                        target[0].style.webkitTransition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                                        target[0].style.transform = 'matrix(1,0,0,1,0,0)';
                                        target[0].style.webkitTransform = 'matrix(1,0,0,1,0,0)';
                                        last[0].style.transition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                                        last[0].style.webkitTransition = 'all 650ms cubic-bezier(0.5,.5,.77,1)';
                                        last[0].style.transform = 'matrix(1,0,0,1,-924,0)';
                                        last[0].style.webkitTransform = 'matrix(1,0,0,1,-924,0)';
                                        setTimeout(function() {
                                            ClearStyles();
                                            if (that.var.view.active) {
                                                that.var.view.active = 0;
                                            } else {
                                                that.var.view.active = 1;
                                            }
                                        }, 775);
                                    }, 50);
                                }, 10);
                                break;
                            default:
                                break;
                        }
                        if (button) {
                            that.activeStates(button);
                        }
                        var scrollers;
                        var scrollBlockBlackList = [
                            'views/nutritionals/library/index.html',
                            'views/analgesics/library/index.html',
                            'views/respiratory/library/index.html'

                        ];
                        if(scrollBlockBlackList.indexOf(url) === -1){
                            setTimeout(function(){
                                scrollers = $('.view[data="'+url+'"]').find(':scolling');
                                scrollers.css({
                                    'backfaceVisibility': 'hidden',
                                    'perspective': '1000'
                                });
                                scrollers.addClass('BlockScrolling');
                            },0);
                        }
                    }, 10);
                });
            });
        },
        BindTaps: function() {
            var that = this;
            var localThis;
            var isActive = 0;
            this.var.navItems.on('tap', function(e) {
                localThis = $(this);
                isActive = localThis.hasClass('active');
                $('#container').attr('data-referer', '');
                $('#container').attr('data-liban2', '1');
                $('#container').attr('data-browseanpage', '0');
                /*setTimeout(function() {
                $('#container').attr('data-liban2','1');
                 $('#container').attr('data-liban1','1');
                }, 10);*/
                /*console.log("View :"+ $('#container .view:eq(0)').attr('data'));*/
               
                if( (that.var.currentURL == 'views/analgesics/library/index.html' && isActive) || (that.var.currentURL == 'views/nutritionals/library/index.html' && isActive)||(that.var.currentURL == 'views/respiratory/library/index.html' && isActive)  ){
                    $('.libraryContainer > div.ScrollNav > div > div.item[data="1"]').trigger('tap');
                    return false;
                }

                else if (that.var.lastURL != that.var.currentURL && isActive) {
                    that.load(localThis.attr('data-href'), 'center');
                } else if (isActive){ 
                    return false;
                }
                if (localThis.attr('data-href')) {
                    that.load(localThis.attr('data-href'), localThis.attr('data-direction'), localThis);
                }
            });
            $('#footer > div.homeButtonWrap > div').on('tap', function(e) {
                $('#homeButton').trigger('tap');
            });
        },
        init: function() {
            var that = this;
            this.var.nav = $('#nav');
            this.var.view[0] = $($('.view')[0]);
            this.var.view[1] = $($('.view')[1]);
            this.var.view.active = 1;
            this.var.navItems = $('#nav .navItem');
            this.BindTaps();
            setTimeout(function() {
                that.var.view[1].load('views/home/index.html');
            }, 0);
            $.extend($.expr[':'],{
                scolling: function(el) {
                    return $(el).css('overflow-y') === 'scroll';
                }
            });


            // $("#content").on("tap", ".Back", function(event){
            //     console.log('back clicked');
            //     that.hardLoad(localStorage.Back);
            // });
        }
    },
    var: {
        langs: ['fr', 'en', 'fr'],
        langswitch: 1,
        container: {},
        popUIblocked:0
    },
    lang: function() {
        var that = this;
        that.nav.init();
        $('#LangToggle').on('tap', function(e) {
                if(  ($('#container').attr('data-referer')==5) ){
                    
                   return
                }
                
            that.var.langswitch++;
            that.var.container.attr('data-lang', that.var.langs[that.var.langswitch % 2]);
            $(this).html(that.var.langs[(that.var.langswitch % 2) + 1].toUpperCase());
        });
    },
    popups: {
        var: {
            running: 0,
            popupClass: 'pop',
            popupActive: function() {
                for (i in this.pairs){
                    if(this.pairs[i].btn.hasClass('active')){
                        return true;
                    }
                } return false;
            },
            pairs: {

            },
            navigating: 0
        },
        reset: function() {
            this.var.running = 0;
            this.var.pairs = {};
        },
        hide: function() {
//console.log("hide");
 var that=this;
 //console.log(that.var.popUIblocked)
           // if(that.var.popUIblocked) return false;
            
            that.var.popUIblocked =1;
           
            setTimeout(function(){
                that.var.popUIblocked = 0;
            },150);
            if(this.var.navigating) return false;
            activeOne = '';
            var that = this;
            for (i in this.var.pairs){
                if(this.var.pairs[i].btn.hasClass('active')){
                   
                    activeOne = this.var.pairs[i];
                }
            }
            if(activeOne == '') return false;
            activeOne.btn.removeClass('active');
            activeOne.pop.velocity({
                translateX: "0px",
                opacity: 0,
            }, {
                duration: 550,
                display: "none",
                easing: [0.5, 0, 0.5, 1],
                complete: function() {
                    if( activeOne.pop){
                    activeOne.btn.removeClass('active');
                    activeOne.pop.hide();
                    }
                    setTimeout(function(){
                        that.var.running = 0;
                    },100);
                }
            });
        },
        show: function(pop, btn) {
           // console.log("show");
            var that=this;
            if(that.var.popUIblocked) return false;
            
            that.var.popUIblocked =1;
            setTimeout(function(){
                that.var.popUIblocked = 0;
            },150);
            var that = this;
            setTimeout(function(){
                if (that.var.running) {
                    return false;
                }
                that.var.running = 1;
                var data = btn.attr('data');
                that.var.pairs[data] = {'btn': btn, 'pop': pop};
                if(that.var.pairs[data].btn.hasClass('active')){ //hide the popup
                    that.hide();
                }
                else{ //show the popup
                    if(that.var.popupActive()){
                        that.hide();
                    }
                    setTimeout(function() {
                        btn.addClass('active');
                        pop[0].style.transform = 'translateX(20px)';
                        pop[0].style.marginLeft = '20px';
                        pop[0].style.opacity = '0';
                        setTimeout(function() {
                            pop[0].style.visibility = 'visible';
                            pop[0].style.display = 'block';
                            setTimeout(function() {
                                pop.velocity({
                                    translateX: "-20px",
                                    opacity: 1,
                                }, {
                                    duration: 550,
                                    easing: [0.5, 0, 0.5, 1],
                                    complete: function() {
                                        setTimeout(function(){
                                            that.var.running = 0;
                                        },100);
                                    }
                                });
                            }, 0);
                        }, 0);
                    }, 0);
                }
            },50);
        },
        init: function(){
            var that = this;
            setTimeout(function(){
                $('#container').on('click', function(e){
                    $('#container div#content  div.pop').on('click', function(e){
                        e.stopPropagation();
                    });
                    that.hide();
                });

            },300);
        }
    },
    popups2: {
        var: {
            running: 0,
            popupClass: 'popup2',
            popupActive: function() {
                for (i in this.pairs){
                    if(this.pairs[i].btn.hasClass('active')){
                        return true;
                    }
                } return false;
            },
            pairs: {

            }
        },
        reset: function() {
            this.var.running = 0;
            this.var.pairs = {};
        },
        hide: function() {
           // if(this.var.popUIblocked) return false;  
            var that = this;
            that.var.popUIblocked =1;
            setTimeout(function(){
                that.var.popUIblocked = 0;
            },150);
            activeOne = '';
            
            for (i in this.var.pairs){
                if(this.var.pairs[i].btn.hasClass('active')){
                    activeOne = this.var.pairs[i];
                }
            }
            if(activeOne == '') return false;
            activeOne.btn.removeClass('active');
            activeOne.pop.velocity({
                translateY: "0px",
                opacity: 0,
            }, {
                duration: 550,
                display: "none",
                easing: [0.5, 0, 0.5, 1],
                complete: function() {
                if( activeOne.pop){
                    activeOne.btn.removeClass('active');
                    activeOne.pop.hide();
                }
                    setTimeout(function(){
                        that.var.running = 0;
                    },100);
                }
            });
        },
        show: function(pop, btn) {
            if(this.var.popUIblocked) return false;
            var that = this;
            that.var.popUIblocked =1;
            setTimeout(function(){
                that.var.popUIblocked = 0;
            },150);
            if (this.var.running) {
                return false;
            }
            this.var.running = 1;
           
            var data = btn.attr('data');
            that.var.pairs[data] = {'btn': btn, 'pop': pop};
            if(that.var.pairs[data].btn.hasClass('active')){ //hide the popup
                that.hide();
            }
            else{ //show the popup
                if(that.var.popupActive()){
                    that.hide();
                }
                setTimeout(function() {
                    btn.addClass('active');
                    pop[0].style.transform = 'translateX(20px)';
                    pop[0].style.marginLeft = '20px';
                    pop[0].style.opacity = '0';
                    setTimeout(function() {
                        pop[0].style.visibility = 'visible';
                        pop[0].style.display = 'block';
                        setTimeout(function() {
                            pop.velocity({
                                translateY: "-20px",
                                opacity: 1,
                            }, {
                                duration: 550,
                                easing: [0.5, 0, 0.5, 1],
                                complete: function() {
                                    setTimeout(function(){
                                        that.var.running = 0;
                                    },100);
                                }
                            });
                        }, 0);
                    }, 0);
                }, 0);
            }

        }
    },
    init: function() {
        this.var.container = $('#container');
        this.lang();
        this.popups.init();
    }
};
app.init();
